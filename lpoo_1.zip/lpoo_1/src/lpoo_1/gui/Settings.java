package lpoo_1.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;

public class Settings extends JDialog
{
	public Settings ()
	{
		this.setTitle("Settings");
		this.setBounds(100, 100, 360, 252);
		this.getContentPane().setLayout(null);
		
		JLabel lblTipoDeJogo = new JLabel("Tipo de Jogo:");
		lblTipoDeJogo.setBounds(10, 10, 100, 15);
		getContentPane().add(lblTipoDeJogo);
		
		final JCheckBox chckbxSetas = new JCheckBox("Mapa de demonstra��o");
		chckbxSetas.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				
				if(chckbxSetas.isSelected())
				{
					
				}
				else
				{
					
				}
			}
		});
		chckbxSetas.setBounds(30, 140, 64, 23);
		getContentPane().add(chckbxSetas);
	}
}
