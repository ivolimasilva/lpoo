package lpoo_1.logic;

public class Position {
	int x, y;
	
	public Position ( int xi, int yi){
		x = xi;
		y = yi;
	}

	public int getX() {
		// TODO Auto-generated method stub
		return x;
	}

	public void setX(int i) {
		// TODO Auto-generated method stub
		x = i;
	}

	public int getY() {
		// TODO Auto-generated method stub
		return y;
	}

	public void setY(int i) {
		// TODO Auto-generated method stub
		y = i;
	}
}
